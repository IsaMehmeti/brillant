@extends('layouts.admin')
@section('pageTitle', 'Shitjet')

@section('content')
<div class="row">
  <div class="col-sm-12">
    <div class="card card-table">
      <div class="card-header">Shitjet</div>
      <div class="card-body">
        <table class="table table-striped table-hover table-fw-widget" id="table1">
          <thead>
            <tr>
              <th>ID</th>
              <th>Klienti</th>
              <th>Adresa e Klientit</th>
              <th>Data</th>
              <th>Materiali</th>
              <th>Perdoruesi</th>
              <th>Veprimet</th>
            </tr>
          </thead>
          <tbody>
            @foreach($sales as $sale)
            <tr class="odd gradeX">
              <td>{{$sale->id}}</td>
              <td>{{$sale->customer_name}}</td>
              <td>{{$sale->customer_address}}</td>
              <td>{{$sale->sale_date}}</td>
               @if($sale->materials()->count() > 0)
                  <td>
                      <div class="col-sm-12">
                        <select class="form-control">
                            @foreach($sale->materials as $material)
                              <option> {{$material->quantity}}m {{$material->material_title}} {{$material->material_category}} - {{$material->amount}}eur</option>
                            @endforeach
                        </select>
                      </div>
                  </td>
                @else
                    <td>
                    </td>
                @endif
              <td>{{$sale->user->name}}</td>
              <td>
                  <a href="{{route('sales.invoice', $sale->id)}}" class="btn mr-2 btn-success">Printoje</a>
                <form action="{{route('sales.destroy', $sale->id)}}" method="POST" class="w-100 d-inline">
                  @csrf
                  @method('Delete')
                <button type="submit" class="btn mr-2 btn-danger">Fshije</button>
                </form>
              </td>
            </tr>
          </tbody>
          @endforeach
        </table>
      </div>
    </div>
  </div>
</div>
@endsection

@section('custom_footer')
  <script src="/lib/datatables/datatables.net/js/jquery.dataTables.js" type="text/javascript"></script>
  <script src="/lib/datatables/datatables.net-bs4/js/dataTables.bootstrap4.js" type="text/javascript"></script>
  <script src="/lib/datatables/datatables.net-buttons/js/dataTables.buttons.min.js" type="text/javascript"></script>
  <script src="/lib/datatables/datatables.net-buttons/js/buttons.flash.min.js" type="text/javascript"></script>
  <script src="/lib/datatables/jszip/jszip.min.js" type="text/javascript"></script>
  <script src="/lib/datatables/pdfmake/pdfmake.min.js" type="text/javascript"></script>
  <script src="/lib/datatables/pdfmake/vfs_fonts.js" type="text/javascript"></script>
  <script src="/lib/datatables/datatables.net-buttons/js/buttons.colVis.min.js" type="text/javascript"></script>
  <script src="/lib/datatables/datatables.net-buttons/js/buttons.print.min.js" type="text/javascript"></script>
  <script src="/lib/datatables/datatables.net-buttons/js/buttons.html5.min.js" type="text/javascript"></script>
  <script src="/lib/datatables/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js" type="text/javascript"></script>
  <script src="/lib/datatables/datatables.net-responsive/js/dataTables.responsive.min.js" type="text/javascript"></script>
  <script src="/lib/datatables/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js" type="text/javascript"></script>
  <script src="/js/app-tables-datatables.js" type="text/javascript"></script>
@endsection
@section('custom_scripts')
<script type="text/javascript">
  $(document).ready(function(){
    //-initialize the javascript
    App.init();
    App.dataTables();
  });
</script>
@endsection
